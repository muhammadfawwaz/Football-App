package com.example.fif.kade3

import com.google.gson.annotations.SerializedName

data class Badge(
    @SerializedName("strTeamBadge")
    var teamBadge: String? = null
)