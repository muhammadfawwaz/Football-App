package com.example.fif.kade3

data class MatchResponse(
    val events: List<Match>
)