package com.example.fif.kade3

interface MainView {
    fun showLoading()
    fun hideLoading()
    fun showMatchList(data: List<Match>)
    fun showTeamBadge(idHomeTeam: List<Badge>, idAwayTeam: List<Badge>)
}