package com.example.fif.kade3

data class BadgeResponse(
    val teams: List<Badge>
)