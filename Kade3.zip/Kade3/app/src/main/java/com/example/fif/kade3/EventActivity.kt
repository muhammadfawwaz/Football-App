package com.example.fif.kade3

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.gson.Gson
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_event.*

class EventActivity : AppCompatActivity(), MainView {
    private lateinit var presenter: MainPresenter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event)

        val match = intent.getParcelableExtra<Match>("match")
        dateEventId.text = match.dateEvent
        if (match.homeScore != null) {
            scoreEventId.text = match.homeScore + getString(R.string.versus) + match.awayScore
        } else {
            scoreEventId.text = getString(R.string.versus)
        }
        team1EventId.text = match.homeTeam
        team2EventId.text = match.awayTeam
        homeGoalDetailsId.text = match.homeGoalDetails
        awayGoalDetailsId.text = match.awayGoalDetails
        homeShotsId.text = match.homeShots
        awayShotsId.text = match.awayShots
        if (match.homeGoalKeeper != null) {
            homeLineUps.text = match.homeGoalKeeper + match.homeDefense + match.homeMidfield + match.homeForward
            awayLineUps.text = match.awayGoalKeeper + match.awayDefense + match.awayMidfield + match.awayForward
        }
        homeSub.text = match.homeSubtitutes
        awaySub.text = match.awaySubtitutes

        val request = ApiRepository()
        val gson = Gson()
        presenter = MainPresenter(this, request, gson)
        presenter.getTeamBadge(match.idHomeTeam, match.idAwayTeam)
    }

    override fun showLoading() {
        pb_event_id.visible()
    }

    override fun hideLoading() {
        pb_event_id.invisible()
    }

    override fun showMatchList(data: List<Match>) {

    }

    override fun showTeamBadge(idHomeTeam: List<Badge>, idAwayTeam: List<Badge>) {
        Log.i("gambarrumah", idHomeTeam[0].teamBadge)
        Picasso.get().load(idHomeTeam[0].teamBadge).into(homeTeamBadgeId)
        Picasso.get().load(idAwayTeam[0].teamBadge).into(awayTeamBadgeId)
    }
}
