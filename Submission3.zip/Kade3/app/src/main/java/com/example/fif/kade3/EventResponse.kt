package com.example.fif.kade3

import com.example.fif.kade3.Model.Event

data class EventResponse(
    val events: List<Event>
)