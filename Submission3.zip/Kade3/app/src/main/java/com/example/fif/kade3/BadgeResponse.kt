package com.example.fif.kade3

import com.example.fif.kade3.Model.Badge

data class BadgeResponse(
    val teams: List<Badge>
)